import styled from 'styled-components'



export const Form = styled.div`
  overflow      : hidden;
  width         : 400px;
  height        : fit-content;
  color         : white;
  flex-shrink : 0;
  border-radius : 20px;
`